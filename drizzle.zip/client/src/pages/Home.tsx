import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (isAuthenticated && user) {
      navigate("/roadmap");
    }
  }, [isAuthenticated, user, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center">
      <div className="text-center space-y-6 max-w-md">
        <div>
          <h1 className="text-4xl font-bold text-primary-foreground mb-2">Roadmap Estratégico</h1>
          <p className="text-lg text-primary-foreground/80">Resoluty Consultoria</p>
        </div>
        
        <p className="text-primary-foreground/70">
          Gerencie suas tarefas, fases e metas de forma visual e intuitiva.
        </p>

        {loading ? (
          <div className="text-primary-foreground">Carregando...</div>
        ) : !isAuthenticated ? (
          <Button
            onClick={() => startLogin()}
            size="lg"
            className="bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            Entrar com Manus
          </Button>
        ) : null}
      </div>
    </div>
  );
}
