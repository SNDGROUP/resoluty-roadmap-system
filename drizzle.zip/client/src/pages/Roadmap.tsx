import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Moon, Sun } from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import RoadmapTimeline from "@/components/RoadmapTimeline";
import TasksTable from "@/components/TasksTable";
import TaskFormDialog from "@/components/TaskFormDialog";
import Dashboard from "@/components/Dashboard";
import ToolbarEditor from "@/components/ToolbarEditor";
import { Task } from "@/types/roadmap";

export default function Roadmap() {
  const { theme, toggleTheme } = useTheme();
  const [activeTab, setActiveTab] = useState("timeline");
  const [isTaskFormOpen, setIsTaskFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [viewMode, setViewMode] = useState<"week" | "month" | "quarter">("month");
  const [activeTool, setActiveTool] = useState<"select" | "pan" | "text" | "shapes" | "diagram" | "icons" | "images" | "mindmap" | "tables" | "areas">("select");

  // Filter states
  const [filterStatus, setFilterStatus] = useState<string[]>([]);
  const [filterPriority, setFilterPriority] = useState<string[]>([]);
  const [filterPillar, setFilterPillar] = useState<string[]>([]);

  // Fetch tasks and phases with filters
  const { data: tasks = [], isLoading: tasksLoading, refetch: refetchTasks } = trpc.tasks.list.useQuery(
    filterStatus.length > 0 || filterPriority.length > 0 || filterPillar.length > 0
      ? { status: filterStatus, priority: filterPriority, pillar: filterPillar }
      : undefined
  );
  const { data: phases = [], isLoading: phasesLoading, refetch: refetchPhases } = trpc.phases.list.useQuery();

  const handleTaskCreated = () => {
    setIsTaskFormOpen(false);
    setEditingTask(null);
    refetchTasks();
    refetchPhases();
  };

  const handleTaskEdit = (task: Task) => {
    setEditingTask(task);
    setIsTaskFormOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Toolbar */}
      {activeTab === "timeline" && (
        <ToolbarEditor
          activeTool={activeTool}
          onToolChange={setActiveTool}
          onUndo={() => console.log("Undo")}
          onRedo={() => console.log("Redo")}
          onExport={() => console.log("Export")}
        />
      )}

      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-primary">Roadmap Estratégico</h1>
              <p className="text-muted-foreground mt-1">Resoluty Consultoria - Gestão de Projetos</p>
            </div>
            <div className="flex items-center gap-3">
              <Button 
                variant="outline"
                size="icon"
                onClick={toggleTheme}
                title={theme === 'dark' ? 'Modo Claro' : 'Modo Noite'}
              >
                {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </Button>
              <Button 
                onClick={() => setIsTaskFormOpen(true)}
                className="bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Tarefa
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
            <TabsTrigger value="tasks">Tarefas</TabsTrigger>
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          </TabsList>

          {/* Timeline Tab */}
          <TabsContent value="timeline" className="space-y-4">
            <div className="flex gap-2 mb-4">
              <Button 
                variant={viewMode === "week" ? "default" : "outline"}
                onClick={() => setViewMode("week")}
                size="sm"
              >
                Semana
              </Button>
              <Button 
                variant={viewMode === "month" ? "default" : "outline"}
                onClick={() => setViewMode("month")}
                size="sm"
              >
                Mês
              </Button>
              <Button 
                variant={viewMode === "quarter" ? "default" : "outline"}
                onClick={() => setViewMode("quarter")}
                size="sm"
              >
                Trimestre
              </Button>
            </div>
            
            {tasksLoading || phasesLoading ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">Carregando timeline...</p>
              </div>
            ) : (
              <RoadmapTimeline 
                tasks={tasks} 
                phases={phases}
                viewMode={viewMode}
                onTaskUpdate={refetchTasks}
                onTaskEdit={handleTaskEdit}
              />
            )}
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks" className="space-y-4">
            {tasksLoading ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">Carregando tarefas...</p>
              </div>
            ) : (
              <TasksTable 
                tasks={tasks}
                onTaskUpdate={refetchTasks}
                onTaskDelete={refetchTasks}
                filterStatus={filterStatus}
                onFilterStatusChange={setFilterStatus}
                filterPriority={filterPriority}
                onFilterPriorityChange={setFilterPriority}
                filterPillar={filterPillar}
                onFilterPillarChange={setFilterPillar}
              />
            )}
          </TabsContent>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-4">
            {tasksLoading || phasesLoading ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">Carregando dashboard...</p>
              </div>
            ) : (
              <Dashboard tasks={tasks} phases={phases} />
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Task Form Dialog */}
      <TaskFormDialog 
        open={isTaskFormOpen}
        onOpenChange={setIsTaskFormOpen}
        onTaskCreated={handleTaskCreated}
        editingTask={editingTask}
      />
    </div>
  );
}
